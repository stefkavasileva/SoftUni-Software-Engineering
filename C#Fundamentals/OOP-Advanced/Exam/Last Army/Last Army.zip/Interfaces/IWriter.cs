﻿public interface IWriter
{
    void WriteLine(string output);
}
