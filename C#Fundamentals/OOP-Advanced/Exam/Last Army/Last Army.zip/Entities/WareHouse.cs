﻿public abstract class WareHouse : IWareHouse
{
    public void EquipArmy(IArmy army)
    {
        throw new System.NotImplementedException();
    }
}

